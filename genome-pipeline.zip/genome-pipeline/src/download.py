"""Fetch a genome from NCBI or load it from a local FASTA file."""

from pathlib import Path
from Bio import Entrez, SeqIO


def download_genome(accession: str, email: str, out_path: Path) -> Path:
    """Download a genome from NCBI by accession number.

    Args:
        accession: NCBI accession (e.g., 'NC_001416.1' for lambda phage).
        email: Your email — NCBI requires this for API access.
        out_path: Where to save the FASTA file.

    Returns:
        Path to the saved FASTA file.
    """
    Entrez.email = email
    print(f"[download] Fetching {accession} from NCBI...")

    handle = Entrez.efetch(
        db="nucleotide",
        id=accession,
        rettype="fasta",
        retmode="text",
    )
    record = SeqIO.read(handle, "fasta")
    handle.close()

    out_path.parent.mkdir(parents=True, exist_ok=True)
    SeqIO.write([record], out_path, "fasta")
    print(f"[download] Saved {len(record.seq):,} bp to {out_path}")
    return out_path


def load_genome(fasta_path: Path):
    """Load a genome from a local FASTA file."""
    record = SeqIO.read(fasta_path, "fasta")
    print(f"[load] Loaded {record.id}: {len(record.seq):,} bp")
    return record
