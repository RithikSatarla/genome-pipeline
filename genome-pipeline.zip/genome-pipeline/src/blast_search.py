"""Optional remote BLAST search for predicted proteins.

NOTE: Remote BLAST queries can take 30s-2min each. We BLAST only the
top-N longest proteins by default. Requires internet access to NCBI.
"""

from Bio.Blast import NCBIWWW, NCBIXML


def blast_protein(protein_seq: str, top_hits: int = 3) -> list[dict]:
    """BLAST a single protein against NCBI's nr database.

    Returns a list of the top hits with description and E-value.
    """
    try:
        handle = NCBIWWW.qblast("blastp", "nr", protein_seq, hitlist_size=top_hits)
        record = NCBIXML.read(handle)
        handle.close()
    except Exception as e:
        return [{"error": f"BLAST failed: {e}"}]

    hits = []
    for alignment in record.alignments[:top_hits]:
        if not alignment.hsps:
            continue
        hsp = alignment.hsps[0]
        hits.append(
            {
                "title": alignment.title[:120],
                "length": alignment.length,
                "e_value": hsp.expect,
                "identity": f"{hsp.identities}/{hsp.align_length}",
            }
        )
    return hits


def blast_top_orfs(orfs, top_n: int = 5) -> list[dict]:
    """BLAST the top-N longest ORFs."""
    sorted_orfs = sorted(orfs, key=lambda o: -o.length_aa)[:top_n]
    results = []
    for orf in sorted_orfs:
        print(f"[blast] Searching {orf.length_aa} aa protein at {orf.start}-{orf.end} ...")
        hits = blast_protein(orf.protein)
        results.append(
            {
                "orf_start": orf.start,
                "orf_end": orf.end,
                "length_aa": orf.length_aa,
                "hits": hits,
            }
        )
    return results
