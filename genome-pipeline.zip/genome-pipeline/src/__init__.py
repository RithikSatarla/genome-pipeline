"""Genome analysis pipeline modules."""
