"""End-to-end genome analysis pipeline.

Usage:
    # Use the bundled demo genome
    python pipeline.py --demo

    # Download a real genome from NCBI (e.g., lambda phage)
    python pipeline.py --accession NC_001416.1 --email you@example.com

    # Use your own FASTA file
    python pipeline.py --input path/to/genome.fasta

    # Optional: run remote BLAST on the top 5 longest ORFs (slow!)
    python pipeline.py --demo --blast
"""

import argparse
import json
from pathlib import Path

import pandas as pd

from src.download import download_genome, load_genome
from src.stats import genome_stats, gc_content_window, gc_skew
from src.orf_finder import find_orfs
from src.proteins import analyze_protein, aa_composition
from src.plots import (
    plot_gc_content,
    plot_gc_skew,
    plot_orf_length_distribution,
    plot_orf_map,
    plot_aa_composition,
)


ROOT = Path(__file__).parent
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"
DEMO_FASTA = DATA_DIR / "demo_genome.fasta"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    src = p.add_mutually_exclusive_group()
    src.add_argument("--demo", action="store_true", help="Use the bundled demo genome.")
    src.add_argument("--accession", type=str, help="NCBI accession to download.")
    src.add_argument("--input", type=str, help="Path to a local FASTA file.")
    p.add_argument("--email", type=str, default="anonymous@example.com",
                   help="Email for NCBI API (required if --accession).")
    p.add_argument("--min-aa", type=int, default=100,
                   help="Minimum ORF length in amino acids (default 100).")
    p.add_argument("--blast", action="store_true",
                   help="Run remote BLAST on top ORFs (slow, requires internet).")
    p.add_argument("--blast-top", type=int, default=5,
                   help="How many longest ORFs to BLAST (default 5).")
    return p.parse_args()


def get_genome(args):
    DATA_DIR.mkdir(exist_ok=True)
    if args.accession:
        out = DATA_DIR / f"{args.accession}.fasta"
        download_genome(args.accession, args.email, out)
        return load_genome(out)
    if args.input:
        return load_genome(Path(args.input))
    # Default: demo
    if not DEMO_FASTA.exists():
        raise FileNotFoundError(
            f"Demo genome not found at {DEMO_FASTA}. "
            f"Run `python scripts/make_demo_genome.py` to generate it, "
            f"or pass --accession or --input."
        )
    return load_genome(DEMO_FASTA)


def main() -> None:
    args = parse_args()
    RESULTS_DIR.mkdir(exist_ok=True)

    print("=" * 60)
    print("  Genome analysis pipeline")
    print("=" * 60)

    record = get_genome(args)
    seq = str(record.seq).upper()

    # ---- Step 1: genome stats ---------------------------------------
    print("\n[1/4] Genome statistics")
    stats = genome_stats(seq)
    print(stats.summary())

    # ---- Step 2: composition plots ----------------------------------
    print("\n[2/4] Sliding-window GC content and skew")
    pos_gc, gc_vals = gc_content_window(seq)
    pos_skew, skew_vals = gc_skew(seq)
    plot_gc_content(pos_gc, gc_vals, stats.gc_content, RESULTS_DIR / "gc_content.png")
    plot_gc_skew(pos_skew, skew_vals, RESULTS_DIR / "gc_skew.png")
    print(f"  Wrote {RESULTS_DIR / 'gc_content.png'}")
    print(f"  Wrote {RESULTS_DIR / 'gc_skew.png'}")

    # ---- Step 3: ORF prediction -------------------------------------
    print(f"\n[3/4] ORF prediction (min {args.min_aa} aa)")
    orfs = find_orfs(seq, min_aa=args.min_aa)
    print(f"  Found {len(orfs)} candidate ORFs")
    if orfs:
        longest = max(orfs, key=lambda o: o.length_aa)
        print(f"  Longest: {longest.length_aa} aa on {longest.strand} strand "
              f"at {longest.start:,}-{longest.end:,}")

    plot_orf_length_distribution(orfs, RESULTS_DIR / "orf_lengths.png")
    plot_orf_map(orfs, len(seq), RESULTS_DIR / "orf_map.png")
    print(f"  Wrote {RESULTS_DIR / 'orf_lengths.png'}")
    print(f"  Wrote {RESULTS_DIR / 'orf_map.png'}")

    # ---- Step 4: protein analysis -----------------------------------
    print("\n[4/4] Protein property analysis")
    rows = []
    for orf in orfs:
        props = analyze_protein(orf.protein)
        rows.append({**orf.to_dict(), **props})
    df = pd.DataFrame(rows)
    df.to_csv(RESULTS_DIR / "orfs.csv", index=False)
    print(f"  Wrote {RESULTS_DIR / 'orfs.csv'} ({len(df)} rows)")

    proteins = [o.protein for o in orfs]
    comp = aa_composition(proteins)
    if comp:
        plot_aa_composition(comp, RESULTS_DIR / "aa_composition.png")
        print(f"  Wrote {RESULTS_DIR / 'aa_composition.png'}")

    summary = {
        "genome_id": record.id,
        "length_bp": stats.length,
        "gc_content": round(stats.gc_content, 4),
        "n_orfs": len(orfs),
        "longest_orf_aa": max((o.length_aa for o in orfs), default=0),
        "min_aa_threshold": args.min_aa,
    }

    # ---- Optional: BLAST --------------------------------------------
    if args.blast and orfs:
        print("\n[bonus] BLAST search (this may take a few minutes)")
        from src.blast_search import blast_top_orfs
        blast_results = blast_top_orfs(orfs, top_n=args.blast_top)
        with open(RESULTS_DIR / "blast_hits.json", "w") as f:
            json.dump(blast_results, f, indent=2)
        print(f"  Wrote {RESULTS_DIR / 'blast_hits.json'}")
        summary["blast_top_n"] = args.blast_top

    with open(RESULTS_DIR / "summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    print("\n" + "=" * 60)
    print(f"  Done. Results in {RESULTS_DIR}/")
    print("=" * 60)


if __name__ == "__main__":
    main()
